// Mobile menu toggle
const menuBtn = document.getElementById('menu-btn');
const mobileMenu = document.getElementById('mobile-menu');

if (menuBtn && mobileMenu) {
  menuBtn.addEventListener('click', () => {
    mobileMenu.classList.toggle('open');
  });
}

// Navbar scroll effect
const navbar = document.getElementById('navbar');
if (navbar) {
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('navbar-scrolled');
      // Change text colors for better contrast when scrolled
      navbar.querySelectorAll('a').forEach(link => {
        if (!link.classList.contains('btn-primary')) {
          link.classList.remove('text-white/90', 'text-white');
          link.classList.add('text-slate-200');
        }
      });
    } else {
      navbar.classList.remove('navbar-scrolled');
      navbar.querySelectorAll('a').forEach(link => {
        if (!link.classList.contains('btn-primary')) {
          link.classList.remove('text-slate-200');
          link.classList.add('text-white/90');
        }
      });
    }
  });
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});