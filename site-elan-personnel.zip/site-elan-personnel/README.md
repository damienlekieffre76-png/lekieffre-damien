# Élan — Site de Développement Personnel

Site moderne et prêt à monétiser sur le développement personnel (habitudes, productivité, mindset, réussite).

## Contenu du site

- **index.html** → Page d'accueil
- **blog.html** → Articles
- **ressources.html** → Livres & outils (affiliation)
- **produits.html** → Produits digitaux
- **a-propos.html** → Histoire du projet
- **contact.html** → Formulaire + newsletter
- **styles.css** + **script.js** → Design et interactions

## Comment mettre le site en ligne (gratuit)

### Option 1 : Netlify (recommandé)
1. Va sur [netlify.com](https://www.netlify.com)
2. Crée un compte
3. Glisse-dépose le dossier entier `site-elan-personnel`
4. Ton site est en ligne en 30 secondes

### Option 2 : Vercel
1. Va sur [vercel.com](https://vercel.com)
2. Importe le dossier ou connecte un repo GitHub

### Option 3 : GitHub Pages
1. Crée un repo GitHub
2. Upload les fichiers
3. Active GitHub Pages dans les settings

## Comment gagner de l'argent avec ce site

1. **Affiliation Amazon**  
   Remplace les liens `#` dans `ressources.html` par tes liens d’affiliation Amazon (programme Partenaires).

2. **Newsletter**  
   Branche un outil comme :
   - ConvertKit
   - MailerLite
   - Brevo (ex-Sendinblue)
   - Beehiiv

3. **Produits digitaux**  
   - Crée tes PDF / templates Notion
   - Vends-les via Gumroad, Lemon Squeezy ou Stripe
   - Remplace les boutons “Acheter” par les vrais liens de paiement

4. **SEO**  
   Écris régulièrement des articles ciblés (ex : “comment prendre de bonnes habitudes”, “méthode deep work”, etc.)

5. **Publicité**  
   Une fois que tu as du trafic : Google AdSense ou sponsors.

## Personnalisation rapide

- Change le nom “Élan” partout si tu veux un autre nom de marque
- Remplace les emails et liens réseaux sociaux
- Ajoute tes vrais témoignages
- Remplace les liens d’affiliation

## Design

- 100 % responsive (mobile + desktop)
- Tailwind CSS via CDN (pas besoin de build)
- Design moderne indigo / ambre

Bon courage pour ton lancement ! 🚀
